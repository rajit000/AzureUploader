# For the Automated of a particular Directory
## We will use to setup the cron [0 0 * * *] which will  run the python file to take the Backup 